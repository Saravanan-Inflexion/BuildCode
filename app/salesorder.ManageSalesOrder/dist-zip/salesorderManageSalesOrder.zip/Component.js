sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("salesorder.ManageSalesOrder.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map